---
id: TPL-authoring
title: Producing a document from the knowledge base
type: template
status: active
confidence: verified
phase: [BID, BUILD]
domain: [delivery]
owner: core-owner-architecture
last_reviewed: 2026-07-25
---

# Producing a document from the knowledge base

## The problem this solves

Three things must meet before a document is worth reading: the reusable
knowledge in this base, the facts of *your* engagement, and a structure. The
base cannot know your engagement, and your engagement should not restate the
base. The orchestrator merges the three and, crucially, **reports what is
missing instead of inventing it**.

```
knowledge base  ──┐
                  ├──> orchestrator ──> reviewable sections ──> assembled document
engagement brief ─┤
                  │
blueprint sections┘
```

## Before anything: fill the brief

`projects/<engagement>/brief.yaml` is where your project's facts live: context,
drivers, constraints, scope, domains and their vendors, platforms, operator
profiles, timeline, and the questionnaire answers still pending.

This file is the single most important input, and the one people skip. A thin
brief produces a generic document, and no amount of prompting fixes that. Mark
each fact as `verified`, `stated-by-client` or `assumed`, exactly as the core
assets do — the drafting pass will refuse to write an assumption as fact.

## The three passes

```bash
cd tools/authoring
cp config.example.yaml config.yaml     # adjust engagement, sections, model
export ANTHROPIC_API_KEY=...           # and KB_MCP_TOKEN if your server needs one

python orchestrate.py check            # first, always
python orchestrate.py plan             # cheap; then READ plan.md
python orchestrate.py draft            # one call per section, cached
python orchestrate.py assemble         # figures, checks, markdown, docx
```

**check** talks to the knowledge server, lists its tools and verifies the ones
the orchestrator needs are present. Run it before anything else; a mismatch
between the server's tool names and the specification is the most common cause
of a failed run.

**plan** retrieves candidate assets per section, reads your brief, and produces
`build/plan.md` containing four things: the asset inventory per section, what
each section needs from the brief and whether it is there, **the gaps**, and a
draft claims register.

This pass exists so that you find out what is missing before paying to draft
around it. Read the gaps. Each one is either an asset somebody should write, an
entry you should add to your brief, or a vendor answer you do not yet have. A
gap silently filled with plausible prose is precisely what this base exists to
prevent.

**draft** writes one section at a time, using only the assets named in the plan.
Sections are cached on a hash of their inputs, so re-running regenerates only
what changed. Iterate on a single section with `--section 8.4`, force a rewrite
with `--force`. If a section comes back as `GAP: ...`, the model is telling you
it cannot write it honestly — fix the input rather than the prompt.

**assemble** strips the citation comments, resolves figure placeholders by
running the view generators, runs consistency checks, writes `document.md` and
calls pandoc for the Word version.

## Where the human decides

Four checkpoints, and none is optional.

1. **The brief**, written by you, before anything runs.
2. **The plan**, read before drafting. Gaps and the claims register are decisions,
   not output.
3. **Each section**, reviewed as prose. The citation comments in the raw section
   files let you check every statement against its asset; they are stripped at
   assembly.
4. **The assembled document**, where the consistency checks report banned words,
   dangling cross-references and unresolved figures.

## Figures

Prose never generates figures. A section emits `[FIGURE: <generator>#<name> —
<caption>]` and the assembler runs the generator from `views/generators/`.

Generators must be self-contained: one script, all its figures, no dependency on
another generator having run first. Name the figure explicitly with `#` when a
generator produces several, or the assembler will refuse to guess.

## Cost control

The plan pass is short and cheap; the drafting pass is where the money goes.
Three habits keep it reasonable: run `plan` until the gaps are closed before
drafting anything; draft section by section rather than regenerating the
document; and let the cache do its job — only edit `config.yaml` section entries
you actually intend to rewrite.

## What this does not do

It does not replace the architect. It retrieves, structures, drafts and checks.
Judgment about what to promise, what to defer and what to refuse remains where
it belongs. The claims register exists to make that judgment explicit rather
than implicit — and moderating a claim is a decision to record, not a defeat.

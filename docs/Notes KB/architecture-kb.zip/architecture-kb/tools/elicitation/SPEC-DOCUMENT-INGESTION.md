---
id: TPL-document-ingestion
title: Document ingestion and knowledge reconciliation — specification supplement
type: template
status: draft
confidence: verified
phase: [BUILD]
domain: [ai-assistance, delivery]
owner: core-owner-automation
last_reviewed: 2026-07-27
related: [TPL-elicitation-proto, TPL-refinement-and-contributions, TPL-planning-and-demo]
---

# Document ingestion and knowledge reconciliation

Feeding a finished architecture document back into the pipeline. It looks like a
convenience feature and it is in fact three different tests, one of which
protects the base from a failure mode that would quietly destroy its value.

---

## 1. The trap, stated first

A document generated from the base and ingested back into it creates **circular
evidence**. Statement `S` asserts something; the document says the same thing
*because of* `S`; ingestion creates `S'` asserting it again, citing the document.
The base now appears to hold two independent sources for one claim, and its
confidence looks stronger than it is.

This is the mechanism by which an evidence-based knowledge base becomes a
self-referential one. It is not hypothetical: the natural way to build this
feature — parse a document, propose statements, record them — produces exactly
that, and nothing in the current pipeline would notice.

Everything below exists to make the loop detectable.

## 2. Provenance on every generated document

**Required change to the assembler.** Every document it produces carries a
provenance block, machine-readable and preserved through Word and PDF:

```yaml
# rendered as a final page and embedded in the document properties
generated_by: elicit assemble
blueprint: BLU-hla-mcx@2
engagement: nordwave-mcx-2027
base_commit: 72ec17e
statements: [S-0007, S-0008, S-0034, ...]     # what this text was rendered from
rendered_at: 2026-07-27T09:14:00Z
```

A document without such a block is, by definition, foreign. That is the whole
discrimination, and it costs one page.

## 3. Three ingestion modes

`elicit ingest-document <file> --engagement X` inspects the provenance block and
selects the mode. The mode is reported, never guessed silently.

### 3.1 Derived — the loop is refused

The block names this base. No statement is created, ever, regardless of what the
prose says. Instead the ingestion produces a **drift report**, which is the
useful thing to do with a returning document:

```
Document derives from this base (commit 72ec17e, 41 statements).
No statement created: ingesting a derived document would create circular evidence.

Drift against the current state:
  3 passages no longer match the statements they were rendered from
    §5.2   "dedicated array, not shared" — S-0008 was superseded on 2026-07-26
    §8.5   "automatic approval for low-risk actions" — no statement supports this
    §10.4  effort range 110–185 — EST-netdevops-telco now reads 142–231
  1 passage present in the document, absent from the base
    §7.3   a paragraph on key rotation with no statement behind it
```

That last category is the valuable one: it detects **hand edits to a generated
document**. Someone opened the Word file, added a paragraph, and the base does
not know. The drift report is how that comes back.

### 3.2 Foreign — the contribution path

No provenance block, or one naming another base. The document is external
material and follows the path of `TPL-refinement-and-contributions` §B: submit,
triage, crystallise, author confirms, lead accepts. Nothing shortcuts it because
the material happens to be long and well written.

One accommodation for documents whose author is unavailable — an old deliverable,
a vendor note, another engagement's work. The author confirmation cannot happen,
so the lead may accept with two consequences recorded: confidence is capped at
`assumed`, and attribution goes to the document rather than to a person. It never
reaches `designed` on the strength of prose nobody can vouch for.

### 3.3 Seed — the recovery benchmark

A special case worth building because it measures the pipeline rather than the
document. Take the document from which the base was originally written, feed it
back, and measure how much of the base it recovers.

The uploaded NetDevOps document is exactly that: 7 029 words, 38 sections, and
the reasoning that later became 15 principles, 13 decisions and 7 patterns. It
is the seed.

```
elicit ingest-document netdevops_v1.docx --mode benchmark --against-assets principles,decisions
```

```
Recovery benchmark
  assets in the base derived from this document   28
  recovered by crystallisation                    19   (68 %)
  recovered but weakened                           5   (a principle recovered without its
                                                        verification clause is not the asset)
  not recovered                                    4
    P-004  graduated autonomy — stated across three paragraphs, never in one
    P-013  assistant configuration is code — appears only as a consequence
    ADR-0010 superseded external inference — the document predates it
    PAT-003 fallback plan lifecycle — present as prose, no reusable shape
  proposed but not in the base                    31   (candidates, or noise)
```

A recovery rate is a **quality metric for the crystallisation pipeline**, and the
only one available that is not a matter of opinion. Track it across versions of
the prompts: a change that raises recovery from 68 % to 80 % is measurable
progress; a change that sounds better and lowers it is not.

The four unrecovered assets are the more instructive output. Three of them fail
for the same reason: they were stated across several paragraphs rather than in
one place, which is what prose does and what structured assets exist to prevent.

## 4. Reconciliation, not merging

Ingestion never merges automatically. It produces a **reconciliation queue**,
sorted so that a human can work through it in one sitting.

| Category | Meaning | Default action |
|---|---|---|
| `already-known` | matches an active statement on subject, predicate and value | discard silently, count it |
| `reinforcing` | same subject and predicate, equivalent value in different words | propose a citation on the existing statement — never a second statement |
| `divergent` | same subject and predicate, incompatible value | raise a conflict, `origin: detected` |
| `new` | no statement on that subject and predicate | propose a statement |
| `unmappable` | the subject cannot be resolved to a canonical one | propose a subject, requires lead approval |

`reinforcing` is the category that protects against the circular-evidence
problem in the foreign case too: a second source saying the same thing adds a
citation, not a second statement. Confidence may rise only when the second source
is genuinely independent, which the lead asserts explicitly.

**Volume control.** A 7 000-word document proposes on the order of 150
candidates; nobody reviews that. The queue is presented by subject, `divergent`
first, then `new`, then `unmappable`. `already-known` and `reinforcing` are
counted and summarised, not listed. A reconciliation session is capped at a
configurable number of decisions, and the rest keeps.

## 5. What this does not do

It does not read a document and update the base. It reads a document and
*proposes*, exactly like every other input. The asymmetry is deliberate: prose is
the least structured input the system accepts, so it is the one that most needs a
human between it and the graph.

It also does not parse diagrams in the document, for the reason given elsewhere:
a wrong reading of an image is invisible.

## 6. Acceptance tests

1. `test_generated_document_carries_provenance` — every document produced by
   `assemble` has the block, and it names the statements it was rendered from.
2. `test_derived_document_creates_no_statement` — ingesting our own output
   produces zero statements and a drift report, whatever the prose says.
3. `test_drift_detects_a_hand_edit` — a paragraph added to the Word file appears
   as "present in the document, absent from the base".
4. `test_drift_detects_a_superseded_statement` — a passage rendered from a
   statement later superseded is flagged.
5. `test_foreign_document_goes_through_triage` — no statement before triage,
   crystallisation and both confirmations.
6. `test_unavailable_author_caps_confidence` — accepted without author
   confirmation, the statements are `assumed` and attributed to the document.
7. `test_reinforcing_adds_a_citation_not_a_statement` — a second source saying
   the same thing does not create a duplicate.
8. `test_divergent_raises_a_detected_conflict` — and leaves both positions active.
9. `test_reconciliation_queue_is_ordered_and_capped` — divergent first, and the
   session stops at the cap with the remainder preserved.
10. `test_recovery_benchmark_reports_a_rate` — running the seed document against
    the assets it produced returns a recovered count, a weakened count and a
    named list of what was missed.

## 7. Prohibitions

- No statement is created from a document that derives from this base.
- No automatic merge: reconciliation proposes, a human decides.
- No confidence above `assumed` without a named person vouching for the content.
- No second statement where a citation on an existing one would do.
- No diagram parsed into statements.

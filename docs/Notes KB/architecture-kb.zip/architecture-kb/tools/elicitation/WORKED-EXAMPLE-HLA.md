# Worked example — three architects producing an HLA section, entirely from GitHub

No command line. Alice, Bob and Charlie work in their browser. The system opens
the issues, renders the cards, catches the disagreement and assembles the
document.

This file doubles as the golden fixture set for the mailbox renderers: every
block below is what `render_question`, `render_proposal`, `render_conflict` and
`render_arbitration` must produce for the fixture engagement `demo-2026`.

**Setup, done once.** `projects/demo-2026/roster.yaml` maps accounts to roles;
the mailbox repository is private; the scan cap is 8 questions.

---

## Issue #14 — the system asks

> **[Q-0001] Which storage backs the management cluster, and is it distinct fr…**
> `role:cloud-architect` `section:5.2` `engagement:demo-2026` `blocks:2`
> Assigned to **@alice-gh**

<!-- rendered card -->

### Which storage backs the management cluster, and is it distinct from the storage of the workload clusters?

**Why this matters**
`P-009` requires an independent failure domain for the management plane. Without
a distinct backing store, HLA section 6.3 cannot claim that the recovery chain
survives an incident affecting the workloads it is meant to recover.

**Please use these terms**
`management-cluster` · `workload-cluster` · `failure-domain`

**Expected**
A storage technology, and whether it is dedicated or shared.

**Previously answered elsewhere**
`mcx-core-2026` → *"dedicated array, not shared with workloads"* — confidence
`designed`.
↳ Confirm this for your engagement, or tell us how it differs here.

**Constrained by** [P-009](../principles/P-009.md) · [ADR-0007](../decisions/ADR-0007.md)

**How to answer**
Comment with `/answer` followed by your reasoning, in your own words.

---

**@alice-gh** commented:

> `/answer` We will not reuse the mcx-core pattern here. The customer already
> operates a tier-1 dual-controller NVMe SAN and wants a single storage
> contract. We take a dedicated LUN group on it for the management cluster —
> dedicated volumes and dedicated controllers ports, but the same array as the
> workload clusters.

---

**@elicit-bot** commented:

> **Nothing is recorded yet.** Here is what I intend to write. Confirm, correct
> or reject.
>
> | | Subject · predicate · value | Confidence |
> |---|---|---|
> | **S-0007** | `management-cluster` · `has_property` · *"tier-1 dual-controller NVMe SAN, dedicated LUN group and controller ports"* | designed |
> | **S-0008** | `management-cluster` · `has_property` · *"same physical array as workload-cluster — logical separation only"* | designed |
>
> Based on `P-009`, `ADR-0007`. Diverges from the prior answer of
> `mcx-core-2026`, which used a physically separate array.
>
> Your words, kept as recorded:
> > We will not reuse the mcx-core pattern here. The customer already operates a
> > tier-1 dual-controller NVMe SAN and wants a single storage contract. We take
> > a dedicated LUN group on it for the management cluster — dedicated volumes
> > and dedicated controllers ports, but the same array as the workload clusters.
>
> `/confirm` · `/edit` + a YAML block · `/reject <reason>`

---

**@alice-gh** commented:

> `/confirm`

---

**@elicit-bot** commented:

> 2 statements recorded. Checks on the new statements:
>
> - contradiction — none
> - stale basis — none
> - **P-009 — ⚠ advisory.** S-0008 states a shared physical array. The principle
>   requires an independent failure domain; logical separation on a shared array
>   does not obviously satisfy it. Not a verdict — flagged for section 6.3.
>
> Issue closed. Section 5.2 now has material.

*The advisory note is the interesting part: the system does not block, it does
not decide, it points at the tension it can see between a fresh answer and a
standing principle.*

---

## Issue #15 — a second expert contests, three days later

Bob was not asked this question. He is contesting a statement about a subject he
owns, which the system routes to the same subject.

**@bob-gh** commented on issue #14:

> `/contest S-0008` A shared array is a single point of failure for the
> management plane. A controller firmware fault or a fabric event takes both
> down at once. We should isolate on an all-flash Ceph cluster on the management
> nodes themselves — three nodes, no shared fabric.

---

**@elicit-bot** opened issue **#15**:

> **[C-0001] contested: management-cluster**
> `conflict` `section:5.2` `section:6.3` Assigned to **@charlie-gh**

### Contested: `management-cluster` · `has_property`

**S-0008** — *"same physical array as workload-cluster — logical separation only"*
@alice-gh · cloud-architect · designed · 2026-07-24 · based on `P-009`, `ADR-0007`

**S-0011** — *"isolated three-node all-flash Ceph, no shared fabric"*
@bob-gh · storage-expert · designed · 2026-07-27

**Advisory** — S-0008 engages `P-009`: a shared array creates a common failure
mode between the management plane and the workloads it recovers. S-0011 engages
`ADR-0007`, which assumed dedicated storage but did not specify a technology.
Advisory only, for the arbitrator.

**Both statements remain active.** Section 5.2 renders both positions and is
marked contested until arbitration.

**To resolve** — `/arbitrate keep <S-xxxx> --reason "<your rationale>"`.
A reason is mandatory.

---

**@charlie-gh** commented:

> `/arbitrate keep S-0011 --reason "P-009 is not negotiable on a mission-critical
> management plane. A single array shared with the workloads reintroduces exactly
> the common failure mode the principle exists to prevent, and the commercial
> argument for a single storage contract does not outweigh it. Alice's constraint
> is real and goes into the risk register as a customer expectation to manage."`

---

**@elicit-bot** commented:

> C-0001 arbitrated by @charlie-gh.
>
> - **S-0011 kept**, active
> - **S-0008 superseded** by S-0011, reason recorded, @alice-gh notified
>
> S-0008 remains in the history with its rationale, and becomes a promotion
> candidate if the shared-array approach proves right on another engagement.
>
> Issue closed.

---

## What lands in the HLA

`elicit assemble --engagement demo-2026` renders section 5.2 from the active
statements. The prose is generated; the facts are the statements; the confidence
wording follows from their metadata.

> ### 5.2 Compute and cloud platform
>
> […] The management cluster is backed by dedicated storage: an isolated
> three-node all-flash cluster located on the management nodes themselves, with
> no shared fabric to the workload clusters. This satisfies the independent
> failure-domain requirement of the architecture principles, and the design
> assumes the three-node minimum is met at each site — a point to confirm during
> the framing work package.
>
> A shared enterprise array was considered and rejected: while it would have kept
> the customer to a single storage contract, it reintroduces a common failure
> mode between the management plane and the workloads that plane exists to
> restore. The commercial expectation of storage consolidation is carried in the
> risk register.

Every sentence above traces to a statement, an author and a date. The rejected
option appears because arbitration recorded it, not because someone remembered
to write it down — which is the difference between a document and a record.

---

## What this scenario demonstrates

- Three people contributed from a browser. None installed anything.
- The divergence from a previous engagement was **explicit**, because the prior
  answer was offered as a default rather than silently assumed.
- A disagreement surfaced three days after the original answer, was detected
  mechanically, and was arbitrated by a named human with a written reason.
- The losing position survived in the history and in the risk register.
- The HLA section is a projection of that record, regenerable at any time.

## Known frictions to expect on a real rollout

- Commenting on issues in a private repository requires write access. Confirm
  with your organisation before inviting contributors.
- The bot must post under a distinguishable identity, so that a card is never
  mistaken for a colleague's opinion.
- Cap the scan. Eight open questions is a queue; forty is spam, and the second
  is unrecoverable — people stop reading.
- Verbatim answers carry engagement material. The mailbox repository is private,
  and that is checked at startup rather than trusted.

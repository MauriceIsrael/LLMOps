"""
Minimal MCP client for the authoring orchestrator.

Speaks JSON-RPC 2.0 over either transport:
  - streamable-http : single POST endpoint, response as JSON or SSE stream
  - sse             : legacy two-channel transport (GET /sse for the stream,
                      POST to the session endpoint announced by the server)

Only what the orchestrator needs: initialize, tools/list, tools/call.
No dependency beyond the standard library, so it runs anywhere Python does.
"""
import json
import queue
import threading
import urllib.request
import urllib.error
import uuid


class MCPError(RuntimeError):
    pass


class MCPClient:
    def __init__(self, base_url, transport="streamable-http", token=None, timeout=60):
        self.base = base_url.rstrip("/")
        self.transport = transport
        self.token = token
        self.timeout = timeout
        self.session_id = None
        self._post_url = None
        self._sse_thread = None
        self._events = queue.Queue()
        self._initialized = False

    # ------------------------------------------------------------------ http
    def _headers(self, accept="application/json, text/event-stream"):
        h = {"Content-Type": "application/json", "Accept": accept}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        if self.session_id:
            h["Mcp-Session-Id"] = self.session_id
        return h

    def _post(self, payload, url=None):
        url = url or self._post_url or f"{self.base}/mcp"
        data = json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data, headers=self._headers(), method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                sid = r.headers.get("Mcp-Session-Id")
                if sid:
                    self.session_id = sid
                ctype = r.headers.get("Content-Type", "")
                body = r.read().decode()
        except urllib.error.HTTPError as e:
            raise MCPError(f"HTTP {e.code} on {url}: {e.read().decode()[:400]}") from None
        except urllib.error.URLError as e:
            raise MCPError(f"cannot reach {url}: {e.reason}") from None
        if not body.strip():
            return None
        if "text/event-stream" in ctype:
            return self._first_json_from_sse(body)
        return json.loads(body)

    @staticmethod
    def _first_json_from_sse(text):
        for line in text.splitlines():
            if line.startswith("data:"):
                chunk = line[5:].strip()
                if chunk and chunk != "[DONE]":
                    return json.loads(chunk)
        return None

    # ------------------------------------------------- legacy sse transport
    def _open_sse(self):
        req = urllib.request.Request(f"{self.base}/sse", headers=self._headers("text/event-stream"))
        stream = urllib.request.urlopen(req, timeout=self.timeout)

        def pump():
            event = None
            for raw in stream:
                line = raw.decode(errors="replace").rstrip("\n")
                if line.startswith("event:"):
                    event = line[6:].strip()
                elif line.startswith("data:"):
                    self._events.put((event, line[5:].strip()))
                    event = None

        self._sse_thread = threading.Thread(target=pump, daemon=True)
        self._sse_thread.start()
        # the server announces the endpoint to POST to
        try:
            ev, data = self._events.get(timeout=self.timeout)
        except queue.Empty:
            raise MCPError("no endpoint event received on /sse; is the transport really sse?")
        if ev != "endpoint":
            raise MCPError(f"expected an endpoint event first, got {ev!r}")
        self._post_url = data if data.startswith("http") else self.base + data

    def _await_result(self, req_id):
        while True:
            try:
                _, data = self._events.get(timeout=self.timeout)
            except queue.Empty:
                raise MCPError("timed out waiting for a response on the sse stream")
            try:
                msg = json.loads(data)
            except json.JSONDecodeError:
                continue
            if msg.get("id") == req_id:
                return msg

    # ------------------------------------------------------------------ rpc
    def _rpc(self, method, params=None):
        req_id = str(uuid.uuid4())
        payload = {"jsonrpc": "2.0", "id": req_id, "method": method, "params": params or {}}
        if self.transport == "sse":
            if self._post_url is None:
                self._open_sse()
            self._post(payload, url=self._post_url)
            msg = self._await_result(req_id)
        else:
            msg = self._post(payload)
        if msg is None:
            raise MCPError(f"empty response to {method}")
        if "error" in msg:
            raise MCPError(f"{method} failed: {msg['error']}")
        return msg.get("result", {})

    def initialize(self):
        result = self._rpc("initialize", {
            "protocolVersion": "2025-06-18",
            "capabilities": {},
            "clientInfo": {"name": "kb-authoring-orchestrator", "version": "1.0"},
        })
        try:
            payload = {"jsonrpc": "2.0", "method": "notifications/initialized"}
            self._post(payload, url=self._post_url) if self.transport == "sse" else self._post(payload)
        except MCPError:
            pass  # some servers do not accept the notification; harmless
        self._initialized = True
        return result

    def list_tools(self):
        if not self._initialized:
            self.initialize()
        return self._rpc("tools/list").get("tools", [])

    def call(self, name, arguments=None):
        if not self._initialized:
            self.initialize()
        result = self._rpc("tools/call", {"name": name, "arguments": arguments or {}})
        if result.get("isError"):
            raise MCPError(f"tool {name} returned an error: {result}")
        return self._flatten(result)

    @staticmethod
    def _flatten(result):
        """Returns the tool payload: structured content if present, else text."""
        if "structuredContent" in result:
            return result["structuredContent"]
        parts = []
        for block in result.get("content", []):
            if block.get("type") == "text":
                parts.append(block["text"])
        text = "\n".join(parts)
        try:
            return json.loads(text)
        except (json.JSONDecodeError, ValueError):
            return text

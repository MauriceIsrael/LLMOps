#!/usr/bin/env python3
"""
Authoring orchestrator.

Turns knowledge base assets plus an engagement brief into a reviewable
architecture document, in three passes with a human checkpoint between each.

    orchestrate.py check      --config config.yaml
    orchestrate.py plan       --config config.yaml
    orchestrate.py draft      --config config.yaml [--section 8.4] [--force]
    orchestrate.py assemble   --config config.yaml

Design notes
------------
* Nothing is written to the knowledge base. The orchestrator only reads.
* Every pass writes to projects/<engagement>/build/ so the output is
  reviewable, diffable and re-runnable.
* Sections are cached individually: re-running `draft` only regenerates what
  changed or what you name explicitly. This is the main cost control.
* The orchestrator never invents content. If the base and the brief have no
  material for a section, the gap is reported, not filled.
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mcp_client import MCPClient, MCPError  # noqa: E402
from kb_adapter import KB  # noqa: E402

try:
    import yaml
except ImportError:
    sys.exit("pyyaml required: pip install pyyaml")

HERE = Path(__file__).parent
REPO = HERE.parent.parent
PROMPTS = HERE / "prompts"

# The orchestrator needs these three. Anything else is handled by the adapter,
# which compensates for what a given server does not provide.
REQUIRED_TOOLS = ["list_assets", "get_asset", "get_decision_trail"]
OPTIONAL_TOOLS = ["query_graph", "get_graph_summary", "get_glossary_term"]


# --------------------------------------------------------------------- utils
def load_config(path):
    cfg = yaml.safe_load(open(path))
    for key in ("engagement", "mcp", "model", "document"):
        if key not in cfg:
            sys.exit(f"config: missing '{key}' section")
    return cfg


def build_dir(cfg):
    d = REPO / "projects" / cfg["engagement"]["id"] / "build"
    (d / "sections").mkdir(parents=True, exist_ok=True)
    return d


def load_brief(cfg):
    p = REPO / "projects" / cfg["engagement"]["id"] / "brief.yaml"
    if not p.exists():
        sys.exit(f"missing engagement brief: {p}\n"
                 f"copy projects/_template/brief.yaml and fill it in — the base "
                 f"holds reusable knowledge, the brief holds your project's facts.")
    return yaml.safe_load(open(p))


def connect(cfg):
    m = cfg["mcp"]
    url = m.get("url", "")
    if url.startswith("${") or not url:
        env_name = m.get("url_env", "KB_MCP_URL")
        url = os.environ.get(env_name, "")
        if not url:
            sys.exit(f"knowledge server URL not set: export {env_name}=https://...")
        m = dict(m, url=url)
    token = os.environ.get(m.get("token_env", "KB_MCP_TOKEN"))
    client = MCPClient(m["url"], transport=m.get("transport", "streamable-http"),
                       token=token, timeout=m.get("timeout", 60))
    return client


def prompt_text(name, **kw):
    raw = (PROMPTS / name).read_text()
    for k, v in kw.items():
        raw = raw.replace("{{" + k + "}}", str(v))
    return raw


def call_model(cfg, system, user, max_tokens=8000):
    """Anthropic Messages API via stdlib. Set ANTHROPIC_API_KEY in the env."""
    import urllib.request
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        sys.exit("ANTHROPIC_API_KEY is not set")
    body = json.dumps({
        "model": cfg["model"]["name"],
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=body, method="POST",
        headers={"content-type": "application/json", "x-api-key": key,
                 "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=300) as r:
        data = json.loads(r.read())
    return "".join(b["text"] for b in data["content"] if b["type"] == "text")


def section_hash(assets, brief_slice, prompt):
    h = hashlib.sha256()
    h.update(json.dumps(assets, sort_keys=True, default=str).encode())
    h.update(json.dumps(brief_slice, sort_keys=True, default=str).encode())
    h.update(prompt.encode())
    return h.hexdigest()[:12]


# ---------------------------------------------------------------- pass: check
def cmd_check(cfg, args):
    client = connect(cfg)
    print(f"connecting to {cfg['mcp']['url']} ({cfg['mcp'].get('transport', 'streamable-http')})")
    info = client.initialize()
    server = info.get("serverInfo", {})
    print(f"  server: {server.get('name', '?')} {server.get('version', '')}")

    kb = KB(client)
    print(f"  tools exposed: {len(kb.tools)}")
    for t in REQUIRED_TOOLS:
        print(f"    {'OK  ' if t in kb.tools else 'MISS'} {t}   (required)")
    for t in OPTIONAL_TOOLS:
        print(f"    {'OK  ' if t in kb.tools else '--  '} {t}   (optional)")
    for t in sorted(set(kb.tools) - set(REQUIRED_TOOLS) - set(OPTIONAL_TOOLS)):
        print(f"    ??   {t}   (unknown to the orchestrator)")

    if "get_graph_summary" in kb.tools:
        try:
            print(f"  graph: {client.call('get_graph_summary')}")
        except MCPError as e:
            print(f"  graph summary failed: {e}")

    print("\n  capability probe:")
    rep = kb.capabilities()
    for wmsg in rep["warnings"]:
        print(f"    WARN {wmsg}")
    if not rep["warnings"]:
        print("    no discrepancy detected")

    missing = [t for t in REQUIRED_TOOLS if t not in kb.tools]
    if missing:
        print(f"\n{len(missing)} required tool(s) missing — the orchestrator will not run.")
        return 1

    try:
        n = len(kb.list_of_type("principle"))
        print(f"\n  smoke test list_assets(principle): {n} returned")
    except MCPError as e:
        print(f"\n  smoke test failed: {e}")
        return 1
    print("\nServer usable. Warnings above are compensated by the adapter, "
          "but fixing them server-side removes the extra calls.")
    return 0


# ----------------------------------------------------------------- pass: plan
def cmd_plan(cfg, args):
    client = connect(cfg)
    kb = KB(client)
    brief = load_brief(cfg)
    out = build_dir(cfg)
    eng = cfg["engagement"]["id"]

    section_map = kb.asset("TPL-hla-section-map")
    sections = cfg["document"]["sections"]
    print(f"planning {len(sections)} section(s) for {eng}")

    phase = cfg["document"]["phase"]
    domains = cfg["document"].get("domains", [])
    pool = []
    for atype in ("principle", "decision", "pattern", "template"):
        pool += kb.select(atype, phase=phase, domains=domains)
    print(f"  {len(pool)} asset(s) match phase {phase} and the configured domains")

    # Assets the server does not serve are read from the local clone.
    for extra in cfg["document"].get("always_include", []):
        a = kb.asset(extra)
        if a:
            fm = a.get("frontmatter") or a
            pool.append({"id": extra, "title": fm.get("title", extra),
                         "type": fm.get("type", "?"), "confidence": fm.get("confidence"),
                         "last_reviewed": str(fm.get("last_reviewed", "")),
                         "source": a.get("source", "server")})
        else:
            print(f"  ! {extra} not available from the server or the clone")

    inventory = {sec["id"]: pool for sec in sections}
    open_questions = KB.open_questions(brief)
    print(f"  open questionnaire items (from the brief): {len(open_questions)}")

    system = prompt_text("pass1_plan.md")
    user = json.dumps({
        "engagement": cfg["engagement"],
        "brief": brief,
        "section_map": section_map,
        "target_sections": sections,
        "candidate_assets": inventory,
        "open_questions": open_questions,
    }, indent=1, default=str)[: cfg["model"].get("max_context_chars", 400000)]

    print("calling the model for the plan...")
    plan = call_model(cfg, system, user, max_tokens=cfg["model"].get("plan_tokens", 8000))
    (out / "plan.md").write_text(plan)
    (out / "plan_inputs.json").write_text(user)
    print(f"\nwritten: {out / 'plan.md'}")
    print(textwrap.dedent("""
        STOP HERE AND READ IT.

        The plan lists, per section, which assets will be used, which gaps exist,
        and the draft claims register. Gaps are the point of this pass: they tell
        you what belongs in your brief, or what must be answered by a vendor
        before you can honestly write the section.

        When you are satisfied, run:  orchestrate.py draft
        """))
    return 0


# ---------------------------------------------------------------- pass: draft
def cmd_draft(cfg, args):
    client = connect(cfg)
    kb = KB(client)
    brief = load_brief(cfg)
    out = build_dir(cfg)
    plan_path = out / "plan.md"
    if not plan_path.exists():
        sys.exit("no plan.md — run `orchestrate.py plan` first and review it.")
    plan = plan_path.read_text()

    cache_path = out / "sections" / ".cache.json"
    cache = json.loads(cache_path.read_text()) if cache_path.exists() else {}

    targets = [s for s in cfg["document"]["sections"]
               if not args.section or s["id"] == args.section]
    if not targets:
        sys.exit(f"section {args.section} is not in the configured section list")

    for sec in targets:
        ids = re.findall(r"\b(P-\d{3}|ADR-\d{4}|PAT-\d{3}|QST-[a-z0-9-]+|EST-[a-z0-9-]+|RSK-[a-z0-9-]+)\b",
                         _plan_slice(plan, sec["id"]))
        assets = []
        for aid in dict.fromkeys(ids):
            a = kb.decision_trail(aid) if aid.startswith("ADR-") else kb.asset(aid)
            if a:
                assets.append(a)
            else:
                print(f"  ! {sec['id']}: {aid} unavailable from server and clone")
        brief_slice = {k: v for k, v in brief.items()
                       if k in sec.get("brief_keys", []) or k in ("context", "scope")}
        system = prompt_text("pass2_section.md",
                             words=sec.get("words", 700),
                             section_id=sec["id"], section_title=sec["title"])
        digest = section_hash(assets, brief_slice, system)
        target = out / "sections" / f"{sec['id'].replace('.', '_')}.md"
        if not args.force and cache.get(sec["id"]) == digest and target.exists():
            print(f"  = {sec['id']} unchanged, kept")
            continue
        user = json.dumps({"section": sec, "plan_extract": _plan_slice(plan, sec["id"]),
                           "assets": assets, "brief": brief_slice}, indent=1, default=str)
        print(f"  > drafting {sec['id']} ({len(assets)} assets)")
        text = call_model(cfg, system, user, max_tokens=cfg["model"].get("section_tokens", 4000))
        target.write_text(text)
        cache[sec["id"]] = digest
        cache_path.write_text(json.dumps(cache, indent=1))
    print(f"\nsections in {out / 'sections'} — review them, then: orchestrate.py assemble")
    return 0


def _plan_slice(plan, section_id):
    m = re.search(rf"(^|\n)#*\s*{re.escape(section_id)}\b(.*?)(?=\n#+\s*\d|\Z)", plan, re.S)
    return m.group(0) if m else plan


# ------------------------------------------------------------- pass: assemble
def cmd_assemble(cfg, args):
    out = build_dir(cfg)
    secs = cfg["document"]["sections"]
    parts, figures, gaps = [], [], []

    title = cfg["document"].get("title", "Solution architecture")
    parts.append(f"% {title}\n% {cfg['engagement'].get('client', '')}\n\n")

    for sec in secs:
        f = out / "sections" / f"{sec['id'].replace('.', '_')}.md"
        if not f.exists():
            gaps.append(sec["id"])
            continue
        body = f.read_text()
        body = re.sub(r"<!--.*?-->", "", body, flags=re.S)          # strip citation comments
        for m in re.finditer(r"\[FIGURE:\s*([^\]—-]+)[—-]\s*([^\]]+)\]", body):
            figures.append((m.group(1).strip(), m.group(2).strip()))
        parts.append(f"# {sec['id']} {sec['title']}\n\n{body.strip()}\n\n")

    doc = "".join(parts)

    # resolve figures
    for i, (generator, caption) in enumerate(figures, 1):
        gen, _, want = generator.partition("#")
        png = _render_figure(gen, out, want or None)
        placeholder = re.compile(r"\[FIGURE:\s*" + re.escape(generator) + r"\s*[—-][^\]]*\]")
        if png and not png.startswith("!"):
            replacement = f"![{caption}]({png})\n\n*Figure {i} — {caption}*"
        elif png == "!empty":
            replacement = (f"> **Figure {i} not produced** — generator `{generator}` ran but "
                           f"wrote no image into the figure directory")
        elif png and png.startswith("!error"):
            replacement = f"> **Figure {i} failed** — `{generator}`: {png[7:]}"
        else:
            replacement = f"> **Figure {i} missing** — no generator named `{gen}`"
        doc = placeholder.sub(replacement, doc, count=1)

    md_path = out / "document.md"
    md_path.write_text(doc)
    print(f"markdown: {md_path}  ({len(doc.split())} words, {len(figures)} figure(s))")

    problems = _consistency_check(doc, cfg)
    for p in problems:
        print(f"  CHECK {p}")
    if gaps:
        print(f"  CHECK sections not drafted: {', '.join(gaps)}")

    ref = cfg["document"].get("reference_docx")
    docx_path = out / f"{cfg['engagement']['id']}-architecture.docx"
    cmd = ["pandoc", str(md_path), "-o", str(docx_path), "--toc", "--toc-depth=2",
           f"--resource-path={out}"]
    if ref and (REPO / ref).exists():
        cmd.append(f"--reference-doc={REPO / ref}")
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"docx: {docx_path}")
    except FileNotFoundError:
        print("pandoc not found — install it, or use the markdown as is")
    except subprocess.CalledProcessError as e:
        print(f"pandoc failed: {e.stderr.decode()[:400]}")
    return 0


def _render_figure(generator, out, want=None):
    script = REPO / "views" / "generators" / f"{generator}.py"
    if not script.exists():
        cand = list((REPO / "views" / "generators").glob(f"*{generator}*.py"))
        if not cand:
            return None
        script = cand[0]
    figdir = out / "figures"
    figdir.mkdir(exist_ok=True)
    env = dict(os.environ, KB_FIG_OUT=str(figdir))
    try:
        subprocess.run([sys.executable, str(script.resolve())], check=True,
                       capture_output=True, cwd=str(figdir), env=env)
    except subprocess.CalledProcessError as e:
        return f"!error:{e.stderr.decode()[:200]}"
    pngs = sorted(figdir.glob("*.png"))
    if not pngs:
        return "!empty"
    if want:
        match = [p for p in pngs if p.stem == want]
        if not match:
            return f"!error:generator produced {len(pngs)} figure(s), none named {want!r}"
        return os.path.relpath(match[0], out)
    if len(pngs) > 1:
        return (f"!error:generator produced {len(pngs)} figures; name the one you want as "
                f"[FIGURE: {generator}#<name> — caption]")
    return os.path.relpath(pngs[0], out)


def _consistency_check(doc, cfg):
    problems = []
    for m in re.finditer(r"section (\d+\.\d+(?:\.\d+)?)", doc, re.I):
        if m.group(1) not in {s["id"] for s in cfg["document"]["sections"]}:
            problems.append(f"cross-reference to section {m.group(1)}, which is not in this document")
    for word in cfg["document"].get("banned_words", []):
        if re.search(rf"\b{re.escape(word)}\b", doc, re.I):
            problems.append(f"banned word present: {word!r}")
    if re.search(r"\[FIGURE:", doc):
        problems.append("unresolved figure placeholder remains")
    return sorted(set(problems))


# ---------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["check", "plan", "draft", "assemble"])
    ap.add_argument("--config", default=str(HERE / "config.yaml"))
    ap.add_argument("--section", help="draft a single section")
    ap.add_argument("--force", action="store_true", help="ignore the section cache")
    args = ap.parse_args()
    cfg = load_config(args.config)
    return {"check": cmd_check, "plan": cmd_plan,
            "draft": cmd_draft, "assemble": cmd_assemble}[args.command](cfg, args)


if __name__ == "__main__":
    sys.exit(main())

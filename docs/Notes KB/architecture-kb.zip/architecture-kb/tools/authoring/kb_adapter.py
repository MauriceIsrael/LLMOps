"""
Adapter between the orchestrator and whatever the knowledge server actually
exposes.

The specification in mcp/SPEC.md describes ten tools. A given server may expose
fewer, or expose them with different fidelity. Rather than let those differences
leak into the orchestrator, they are isolated here — the same reasoning as
principle P-006: one chain, specificities confined to a connector layer.

Currently targets the LLMOps server, which exposes six tools:
    get_graph_summary, list_assets, get_asset, get_decision_trail,
    get_glossary_term, query_graph

Known gaps of that server, compensated below:
  * `list_assets` accepts `phase` and `domain` but the graph node does not store
    them, so the filters are silently ignored. We filter client-side on the
    front matter returned by `get_asset`, and `check` reports the problem.
  * YAML assets (questionnaires, estimates, risk registers) are not ingested.
    We fall back to reading them from the local clone.
  * No `search_assets`, `list_open_questions`, `render_view` or `draft_asset`.
    Retrieval leans on the section map, open questions come from the brief,
    figures are rendered locally and drafting stays a human pull request.
"""
import json
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None

REPO = Path(__file__).resolve().parent.parent.parent

CORE_TOOLS = ["list_assets", "get_asset", "get_decision_trail"]
NICE_TOOLS = ["query_graph", "get_graph_summary", "get_glossary_term"]
LOCAL_DIRS = ["questionnaires", "estimates", "risks"]


class KB:
    def __init__(self, client):
        self.c = client
        self._cache = {}
        self.tools = {t["name"]: t for t in client.list_tools()}

    # ------------------------------------------------------------ capability
    def capabilities(self):
        report = {"present": [], "missing": [], "warnings": []}
        for t in CORE_TOOLS + NICE_TOOLS:
            (report["present"] if t in self.tools else report["missing"]).append(t)

        # filter fidelity: two different domains must not return the same set
        try:
            a = self._ids(self.c.call("list_assets", {"type": "principle", "domain": "ai-assistance"}))
            b = self._ids(self.c.call("list_assets", {"type": "principle", "domain": "transport"}))
            if a and a == b:
                report["warnings"].append(
                    "list_assets ignores the `domain` filter: two different domains return the "
                    "same set. Filtering is done client-side instead, at the cost of extra calls.")
        except Exception as e:                                   # noqa: BLE001
            report["warnings"].append(f"could not test filter fidelity: {e}")

        # yaml ingestion
        missing_yaml = []
        for d in LOCAL_DIRS:
            for f in (REPO / d).glob("*.yaml"):
                aid = f.stem
                try:
                    got = self.c.call("get_asset", {"id": aid})
                    if not got or (isinstance(got, str) and "not found" in got.lower()):
                        missing_yaml.append(aid)
                except Exception:                                # noqa: BLE001
                    missing_yaml.append(aid)
        if missing_yaml:
            report["warnings"].append(
                f"{len(missing_yaml)} YAML asset(s) absent from the server "
                f"({', '.join(missing_yaml)}); read from the local clone instead.")
        return report

    @staticmethod
    def _ids(payload):
        if isinstance(payload, list):
            return sorted(a.get("id", "") for a in payload if isinstance(a, dict))
        if isinstance(payload, dict):
            return [payload.get("id", "")]
        return []

    # ---------------------------------------------------------------- access
    def asset(self, asset_id):
        """Full asset. Falls back to the local clone when the server lacks it."""
        if asset_id in self._cache:
            return self._cache[asset_id]
        data = None
        try:
            data = self.c.call("get_asset", {"id": asset_id})
        except Exception:                                        # noqa: BLE001
            data = None
        if not data or (isinstance(data, str) and "not found" in data.lower()):
            data = self._local(asset_id)
        self._cache[asset_id] = data
        return data

    def _local(self, asset_id):
        for d in LOCAL_DIRS:
            p = REPO / d / f"{asset_id}.yaml"
            if p.exists():
                if yaml is None:
                    return {"id": asset_id, "raw_body": p.read_text(), "source": "local"}
                doc = yaml.safe_load(p.read_text())
                doc["source"] = "local clone"
                return doc
        return None

    def decision_trail(self, asset_id):
        return self.c.call("get_decision_trail", {"id": asset_id})

    def glossary(self, term):
        if "get_glossary_term" not in self.tools:
            return None
        try:
            return self.c.call("get_glossary_term", {"term": term})
        except Exception:                                        # noqa: BLE001
            return None

    # ------------------------------------------------------------- selection
    def list_of_type(self, asset_type, status="active"):
        payload = self.c.call("list_assets", {"type": asset_type, "status": status})
        if isinstance(payload, dict):
            payload = [payload]
        if isinstance(payload, str):
            payload = [json.loads(line) for line in payload.splitlines() if line.strip()]
        return payload or []

    def select(self, asset_type, phase=None, domains=None, status="active"):
        """Type filter server-side, phase and domain filtered on the front matter.

        This is the compensation for the server ignoring those two arguments.
        It costs one `get_asset` per candidate, which is why results are cached
        and why the plan pass is the only one that calls it broadly.
        """
        out = []
        for entry in self.list_of_type(asset_type, status=status):
            aid = entry.get("id") if isinstance(entry, dict) else str(entry)
            if not aid:
                continue
            full = self.asset(aid) or {}
            fm = full.get("frontmatter") or full
            if phase and phase not in (fm.get("phase") or []):
                continue
            if domains:
                if not set(fm.get("domain") or []) & set(domains):
                    continue
            out.append({"id": aid,
                        "title": fm.get("title", entry.get("title", "")),
                        "type": fm.get("type", asset_type),
                        "confidence": fm.get("confidence"),
                        "last_reviewed": str(fm.get("last_reviewed", "")),
                        "domain": fm.get("domain", []),
                        "phase": fm.get("phase", [])})
        return out

    # --------------------------------------------------------------- project
    @staticmethod
    def open_questions(brief):
        """The server has no such tool; the brief is the authoritative place."""
        return [q for q in (brief.get("open_questions") or [])
                if str(q.get("status", "pending")).lower() != "answered"]

---
id: TPL-server-fixes
title: Knowledge server — defect report and fix specification
type: template
status: active
confidence: verified
phase: [BUILD]
domain: [ai-assistance]
owner: core-owner-automation
last_reviewed: 2026-07-26
related: [TPL-mcp-spec]
---

# Knowledge server — defect report and fix specification

Observed on the LLMOps server, 2026-07-26, through its own MCP tools. The
implementation was not inspected; every finding below is reproducible from the
client side using the calls given in each section.

Fix in the order listed. Defect 1 is the only one that can silently mislead a
consumer, so it comes first even though defect 2 blocks more functionality.

---

## Defect 1 — `list_assets` silently ignores `phase` and `domain`

**Severity: high.** A caller cannot detect it, and an agent will present an
unfiltered set as a filtered one.

**Reproduce**

```
list_assets(type="principle", domain="ai-assistance")   -> 15 results
list_assets(type="principle", domain="transport")       -> the same 15
query_graph("MATCH (a:Asset) WHERE a.id='P-012' RETURN a.*")
    -> no `phase` property, no `domain` property on the node
```

**Cause.** The front-matter parser reads `phase` and `domain` correctly — they
appear in `get_decision_trail` output — but they are not persisted on the graph
node, so the handler has nothing to filter on and drops the arguments.

**Required fix.** These are multi-valued attributes on a graph database, so
model them as relationships rather than as scalar columns. That is the whole
point of holding this in Kùzu rather than in a table.

```cypher
CREATE NODE TABLE Phase(name STRING, PRIMARY KEY(name));
CREATE NODE TABLE Domain(name STRING, PRIMARY KEY(name));
CREATE REL TABLE APPLIES_TO(FROM Asset TO Phase);
CREATE REL TABLE IN_DOMAIN(FROM Asset TO Domain);
```

At ingestion, create the `Phase` and `Domain` nodes if absent and attach one
relationship per value. `list_assets` then filters with a join instead of a
property comparison.

**Non-negotiable behaviour.** If for any reason a filter cannot be honoured, the
tool must return an error naming the unsupported argument. It must never return
an unfiltered set. Silence is the defect; an error is a correct answer.

**Acceptance**

```
list_assets(type="principle", domain="ai-assistance")  -> exactly P-012..P-015
list_assets(type="principle", domain="transport")      -> a strictly different set
list_assets(type="decision", phase="RUN")              -> only ADRs whose phase includes RUN
list_assets(type="principle", domain="does-not-exist") -> empty list, not an error, not 15
```

---

## Defect 2 — YAML assets are not ingested

**Severity: high.** Blocks gap analysis and estimation in the planning pass.

**Reproduce**

```
get_asset("QST-core-ems")        -> not found
get_asset("EST-netdevops-telco") -> not found
get_asset("RSK-netdevops-telco") -> not found
query_graph("MATCH (a:Asset) RETURN a.type, count(*)")
    -> principle 15, decision 13, pattern 7, template 5, document 4 — no questionnaire,
       no estimate, no risk-register
```

**Cause.** The ingester looks for a Markdown front-matter block delimited by
`---`. In a `.yaml` asset the whole file *is* the metadata, so no block is found
and the file is skipped.

**Required fix.** Branch on the extension.

- `.md` — parse the leading `---` block as front matter, the remainder as body,
  and split the body on level-2 headings into a `sections` map, exactly as
  `get_decision_trail` already does.
- `.yaml` — load the whole document as the front matter. There is no body.
  Preserve the nested structures verbatim (`groups`, `work_packages`, `risks`)
  and expose them under a `content` key so that consumers can read the questions,
  the effort ranges and the risk entries without a second file access.

Use `schema/frontmatter.schema.json` as the contract for both branches.

**Acceptance**

```
get_asset("QST-core-ems")        -> id, title, type=questionnaire, confidence,
                                    last_reviewed, and content.groups with 16 questions
get_asset("EST-netdevops-telco") -> content.work_packages with 7 entries and
                                    content.variance_drivers with 5 entries
get_asset("RSK-netdevops-telco") -> content.risks with 12 entries
list_assets(type="questionnaire") -> 3 results
```

---

## Defect 3 — prose files ingested as assets, with identifier collisions

**Severity: medium.** Pollutes retrieval and loses data through collisions.

**Reproduce**

```
query_graph("MATCH (a:Asset) WHERE a.type='document' RETURN a.id, a.title")
    -> README (titled "Decisions"), CONTRIBUTING, GOVERNANCE, deltas
```

Several directories contain a `README.md`; one identifier survived, the others
were overwritten.

**Cause.** Files without front matter are ingested with an identifier derived
from the filename and a type inferred as `document`.

**Required fix.** Ingest only files carrying a valid `id` in their front matter.
Everything else is repository documentation, not a knowledge asset. Reuse the
existing validator rather than reimplementing the rule:

```bash
python schema/validate.py     # already enforces exactly this contract
```

Log skipped files at debug level so an author who forgot their front matter can
see why their asset is absent, and fail the ingestion on a duplicate identifier
rather than overwriting silently.

**Acceptance**

```
query_graph("MATCH (a:Asset) WHERE a.type='document' RETURN count(*)")  -> 0
query_graph("MATCH (a:Asset) RETURN count(*)")                          -> 45
    (15 principles + 13 decisions + 7 patterns + 3 questionnaires
     + 1 estimate + 1 risk-register + 5 templates)
ingesting two assets with the same id -> ingestion fails with both paths named
```

---

## Defect 4 — the glossary yields one term instead of its entries

**Severity: low.**

**Reproduce**

```
get_graph_summary()  ->  total_glossary_terms: 1
```

`glossary/glossary.md` contains roughly ten definitions, each a bold term
followed by an em dash and its definition.

**Required fix.** Parse the entries, not the file. One `GlossaryTerm` node per
definition, with `term` and `definition`. `get_glossary_term` should match
case-insensitively and on the singular form.

**Acceptance**

```
get_graph_summary()                -> total_glossary_terms >= 10
get_glossary_term("break-glass")   -> the definition
get_glossary_term("Break-Glass")   -> the same definition
```

---

## Defect 5 — `get_asset` omits the epistemic metadata

**Severity: medium**, because it defeats the purpose of carrying `confidence`
at all.

`get_decision_trail` returns `confidence`, `last_reviewed`, `frontmatter`,
`sections` and `raw_body`. `get_asset` should return the same shape for every
asset type. Without `confidence` and `last_reviewed` in the payload, a consuming
agent cannot state whether what it is asserting is verified, vendor-stated or
assumed — which is the discipline the whole base is built on.

**Acceptance**

```
get_asset("P-002")  -> includes confidence, last_reviewed, frontmatter, sections
get_asset("ADR-0005") -> same shape as get_decision_trail minus the trail
```

---

## Not defects — deliberate deviations from the specification

The specification lists ten tools; six are implemented. The four absent ones are
compensated in `tools/authoring/kb_adapter.py` and are **not** required:

- `search_assets` — retrieval leans on `TPL-hla-section-map` and `list_assets`.
- `list_open_questions` — the engagement brief is the authoritative source.
- `render_view` — figures are generated locally from `views/generators/`.
- `draft_asset` — drafting stays a human pull request, which is the intended
  governance anyway.

Adding `search_assets` later would be the most useful of the four. `draft_asset`
should only be added with the pull-request-only constraint of the specification.

---

## Verification after the fixes

From a clone of the knowledge base, with the server configured:

```bash
cd tools/authoring
python orchestrate.py check --config config.yaml
```

The capability probe tests defects 1 and 2 directly. When all five are fixed it
prints `no discrepancy detected`, and the adapter stops compensating — which
also removes one `get_asset` call per candidate asset in the planning pass.

## What kind of asset is this?

- [ ] Decision (ADR) — a choice with alternatives
- [ ] Principle — a rule that constrains future choices
- [ ] Pattern — a solution I would repeat
- [ ] Questionnaire / estimate / risk update
- [ ] View generator
- [ ] Project instance (no core change)
- [ ] Harvest

## Checklist

- [ ] Front matter validates (`python schema/validate.py`)
- [ ] `confidence` reflects reality: `verified` only for what was directly observed
- [ ] Rejected alternatives are documented (decisions) or "when not to use" is filled (patterns)
- [ ] No client-identifying material outside `projects/`
- [ ] If this supersedes something, the superseded asset is updated with `superseded_by`

## Promotion (fill only if moving something out of a project instance)

Where has this occurred before, and what was generalized away?

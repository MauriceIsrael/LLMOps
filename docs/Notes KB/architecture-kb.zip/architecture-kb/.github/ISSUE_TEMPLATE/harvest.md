---
name: Phase harvest
about: Capture what the engagement taught us, at the end of a phase
labels: harvest
---

**Engagement:**
**Phase:** BID / BUILD / RUN
**Architect:**
**Target date:** (set at phase kickoff)

## To review

- [ ] Effort actuals against `estimates/EST-*.yaml`, and variance drivers
- [ ] Risks that materialized, risks that never did
- [ ] Decisions whose consequences differed from what was recorded
- [ ] Anything now seen twice → promotion candidate
- [ ] Assets that are no longer true → deprecate

## Output

One pull request, branch `harvest/<engagement>-<phase>`.

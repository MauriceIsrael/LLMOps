---
name: Decision needed
about: Flag a choice that must be recorded as an ADR
labels: decision
---

**Context:** what forces the choice now?
**Options on the table:**
**Who decides, and by when:**
**Engagement affected:**

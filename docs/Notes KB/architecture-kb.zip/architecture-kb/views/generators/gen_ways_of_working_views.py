#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Figures for the ways-of-working synthesis note."""
import importlib.util

import os, pathlib
_LIB = pathlib.Path(__file__).resolve().parent.parent / "lib"
spec = importlib.util.spec_from_file_location("db", _LIB / "diagram_base.py")
db = importlib.util.module_from_spec(spec)
spec.loader.exec_module(db)
box, zone, arrow, label, svg = db.box, db.zone, db.arrow, db.label, db.svg
COL, TXT, TXT2, ARROW = db.COL, db.TXT, db.TXT2, db.ARROW
OUT = os.environ.get("KB_FIG_OUT", os.getcwd()) + "/"


def plain(pts, width=1.8, dashed=False):
    d = "M" + " L".join(f"{p[0]} {p[1]}" for p in pts)
    dash = ' stroke-dasharray="7 6"' if dashed else ""
    return f'<path d="{d}" fill="none" stroke="{ARROW}" stroke-width="{width}"{dash}/>'


# ============================================================ 1. KNOWLEDGE BASE
b = []
b.append(box(120, 60, 460, 80, "gray", "Architects",
             ["BID · BUILD · RUN"], tsize=21))
b.append(box(700, 60, 460, 80, "amber", "Agentic framework",
             ["assembles, never decides"], tsize=21))
b.append(arrow([(350, 230), (350, 142)]))
b.append(arrow([(930, 230), (930, 142)]))
b.append(box(120, 232, 1040, 80, "teal", "Knowledge server (read-only)",
             ["typed tools, filterable by phase and domain — whole assets, never fragments"], tsize=21))
b.append(arrow([(640, 400), (640, 314)]))
b.append(zone(120, 402, 1040, 300, "Knowledge base — one Git repository", "purple"))
chips = [("Principles", "durable rules"), ("Decisions", "with alternatives"),
         ("Patterns", "and when not to"), ("Questionnaires", "with the stakes"),
         ("Effort, risks", "with actuals"), ("Views", "as code")]
for i, (t, s) in enumerate(chips):
    x = 160 + (i % 3) * 330
    y = 460 + (i // 3) * 110
    b.append(box(x, y, 290, 80, "purple", t, [s], tsize=19, ssize=15))
b.append(label(640, 675, "Engagement instances reference these assets and record only their deltas",
               16, "middle", COL["purple"]["sub"]))
b.append(plain([(120, 100), (60, 100), (60, 790), (500, 790)], dashed=True))
b.append(arrow([(500, 790), (520, 790)], dashed=True))
b.append(label(90, 450, "proposals", 16, "middle", TXT2))
b.append(box(520, 762, 340, 56, "amber", "Reviewed pull request",
             ["the only write path"], tsize=19))
b.append(arrow([(862, 790), (1220, 790), (1220, 560), (1162, 560)]))
svg(1280, 840, "\n".join(b), OUT + "wow_knowledge_base.svg")

# ============================================================ 2. AUTHORING PASSES
b = []
b.append(zone(60, 50, 1160, 150, "Inputs prepared by the architect, once per engagement", "purple"))
b.append(box(100, 100, 340, 80, "purple", "Engagement brief",
             ["the facts the base cannot know"], tsize=19))
b.append(box(470, 100, 340, 80, "purple", "Document configuration",
             ["sections, budgets, vocabulary"], tsize=19))
b.append(box(840, 100, 340, 80, "purple", "Knowledge base",
             ["frames and constraints"], tsize=19))

steps = [
    ("1 · check", "server capability probe", "tool coverage, filter fidelity", "teal"),
    ("2 · plan", "inventory, coverage, gaps", "the gap list and claims register", "teal"),
    ("3 · draft", "one section at a time, cached", "prose with citations, or GAP", "teal"),
    ("4 · assemble", "figures, checks, rendering", "document plus defect report", "teal"),
]
y = 250
for i, (title, sub, out, col) in enumerate(steps):
    b.append(box(100, y, 420, 82, col, title, [sub], tsize=21, ssize=16))
    b.append(box(600, y, 300, 82, "gray", "produces", [out], tsize=17, ssize=15))
    b.append(arrow([(522, y + 41), (598, y + 41)]))
    if i < 3:
        b.append(box(960, y, 260, 82, "amber", "Human gate", ["read before continuing"], tsize=17, ssize=14))
        b.append(arrow([(902, y + 41), (958, y + 41)]))
        b.append(arrow([(310, y + 82), (310, y + 128)]))
    else:
        b.append(box(960, y, 260, 82, "amber", "Chief architect", ["accepts or returns"], tsize=17, ssize=14))
        b.append(arrow([(902, y + 41), (958, y + 41)]))
    y += 128
b.append(arrow([(60, 200), (60, 291), (98, 291)]))
b.append(label(640, 215, "the gap list is the point of pass 2: it says what to go and find out",
               16, "middle", COL["amber"]["title"], True))
svg(1280, 790, "\n".join(b), OUT + "wow_authoring_passes.svg")

# ============================================================ 3. ELICITATION LOOP
b = []
b.append(box(60, 50, 340, 80, "teal", "Network architect", ["southbound chain"], tsize=19))
b.append(box(470, 50, 340, 80, "teal", "Security architect", ["zoning, entitlements"], tsize=19))
b.append(box(880, 50, 340, 80, "teal", "Delivery lead", ["effort, milestones"], tsize=19))
for x in (230, 640, 1050):
    b.append(arrow([(x, 130), (x, 178)]))
b.append(box(60, 180, 1160, 84, "purple", "Framed conversation",
             ["the system asks; it restates the canonical vocabulary; it confirms before recording"], tsize=21))
b.append(arrow([(640, 264), (640, 312)]))
b.append(box(340, 314, 600, 84, "purple", "Typed statements",
             ["subject, predicate, value — with author, confidence and verbatim"], tsize=21))
b.append(arrow([(640, 398), (640, 446)]))
b.append(box(340, 448, 600, 84, "coral", "Checks",
             ["contradiction, principle violation, stale basis — by query, not by judgement"], tsize=21))
b.append(arrow([(480, 532), (480, 580)]))
b.append(arrow([(800, 532), (800, 580)]))
b.append(box(160, 582, 500, 80, "amber", "Conflicts to arbitrate",
             ["surfaced, never resolved alone"], tsize=19))
b.append(box(700, 582, 500, 80, "gray", "Rendered document",
             ["a projection of the current state"], tsize=19))
b.append(plain([(160, 622), (40, 622), (40, 90), (58, 90)]))
b.append(arrow([(50, 90), (58, 90)]))
b.append(label(60, 676, "returned to its author", 15, "start", TXT2))
svg(1280, 710, "\n".join(b), OUT + "wow_elicitation_loop.svg")

# ============================================================ 4. STATE VS REASONING
b = []
b.append(box(60, 50, 1160, 80, "teal", "Experts and chief architect",
             ["external actors: they answer in their own time, sometimes not at all"], tsize=21))
b.append(arrow([(640, 130), (640, 178)], both=True))
b.append(box(340, 180, 600, 80, "amber", "Question channel",
             ["a mailbox, not a function call"], tsize=21))
b.append(arrow([(640, 260), (640, 308)], both=True))
b.append(box(60, 310, 1160, 90, "purple", "Durable process — the only stateful component",
             ["question lifecycle, routing, waiting, resumption, audit trail"], tsize=21))
b.append(arrow([(640, 400), (640, 448)], both=True))
b.append(label(660, 424, "bounded tasks", 16, "start", TXT2))
tasks = ["Gap detection", "Question writing", "Answer interpretation", "Coherence review"]
for i, t in enumerate(tasks):
    b.append(box(60 + i * 296, 450, 272, 80, "coral", t, [], tsize=18))
b.append(label(640, 552, "stateless agent tasks — replaceable, and never authoritative",
               16, "middle", COL["coral"]["title"]))
b.append(arrow([(196, 578), (196, 626)]))
b.append(label(216, 602, "read", 15, "start", TXT2))
b.append(plain([(1200, 400), (1250, 400), (1250, 656), (960, 656)]))
b.append(arrow([(980, 656), (960, 656)]))
b.append(label(1120, 690, "writes, historised", 15, "middle", TXT2))
b.append(box(340, 628, 600, 80, "gray", "Graph and Git",
             ["statements, assets, history"], tsize=21))
svg(1280, 740, "\n".join(b), OUT + "wow_state_vs_reasoning.svg")
print("four figures generated")

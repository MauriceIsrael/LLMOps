#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Figures for the ways-of-working synthesis note."""
import importlib.util

import os, pathlib
_LIB = pathlib.Path(__file__).resolve().parent.parent / "lib"
spec = importlib.util.spec_from_file_location("db", _LIB / "diagram_base.py")
db = importlib.util.module_from_spec(spec)
spec.loader.exec_module(db)
box, zone, arrow, label, svg = db.box, db.zone, db.arrow, db.label, db.svg
COL, TXT, TXT2, ARROW = db.COL, db.TXT, db.TXT2, db.ARROW
OUT = os.environ.get("KB_FIG_OUT", os.getcwd()) + "/"


def plain(pts, width=1.8, dashed=False):
    d = "M" + " L".join(f"{p[0]} {p[1]}" for p in pts)
    dash = ' stroke-dasharray="7 6"' if dashed else ""
    return f'<path d="{d}" fill="none" stroke="{ARROW}" stroke-width="{width}"{dash}/>'


# ============================================================ 1. KNOWLEDGE BASE
b = []
b.append(box(120, 60, 460, 80, "gray", "Architects",
             ["BID · BUILD · RUN"], tsize=21))
b.append(box(700, 60, 460, 80, "amber", "Agentic framework",
             ["assembles, never decides"], tsize=21))
b.append(arrow([(350, 230), (350, 142)]))
b.append(arrow([(930, 230), (930, 142)]))
b.append(box(120, 232, 1040, 80, "teal", "Knowledge server (read-only)",
             ["typed tools, filterable by phase and domain — whole assets, never fragments"], tsize=21))
b.append(arrow([(640, 400), (640, 314)]))
b.append(zone(120, 402, 1040, 300, "Knowledge base — one Git repository", "purple"))
chips = [("Principles", "durable rules"), ("Decisions", "with alternatives"),
         ("Patterns", "and when not to"), ("Questionnaires", "with the stakes"),
         ("Effort, risks", "with actuals"), ("Views", "as code")]
for i, (t, s) in enumerate(chips):
    x = 160 + (i % 3) * 330
    y = 460 + (i // 3) * 110
    b.append(box(x, y, 290, 80, "purple", t, [s], tsize=19, ssize=15))
b.append(label(640, 675, "Engagement instances reference these assets and record only their deltas",
               16, "middle", COL["purple"]["sub"]))
b.append(plain([(120, 100), (60, 100), (60, 790), (500, 790)], dashed=True))
b.append(arrow([(500, 790), (520, 790)], dashed=True))
b.append(label(90, 450, "proposals", 16, "middle", TXT2))
b.append(box(520, 762, 340, 56, "amber", "Reviewed pull request",
             ["the only write path"], tsize=19))
b.append(arrow([(862, 790), (1220, 790), (1220, 560), (1162, 560)]))
svg(1280, 840, "\n".join(b), OUT + "wow_knowledge_base.svg")

# ============================================================ 2. AUTHORING PASSES
b = []
b.append(zone(60, 50, 1160, 150, "Inputs prepared by the architect, once per engagement", "purple"))
b.append(box(100, 100, 340, 80, "purple", "Engagement brief",
             ["the facts the base cannot know"], tsize=19))
b.append(box(470, 100, 340, 80, "purple", "Document configuration",
             ["sections, budgets, vocabulary"], tsize=19))
b.append(box(840, 100, 340, 80, "purple", "Knowledge base",
             ["frames and constraints"], tsize=19))

steps = [
    ("1 · check", "server capability probe", "tool coverage, filter fidelity", "teal"),
    ("2 · plan", "inventory, coverage, gaps", "the gap list and claims register", "teal"),
    ("3 · draft", "one section at a time, cached", "prose with citations, or GAP", "teal"),
    ("4 · assemble", "figures, checks, rendering", "document plus defect report", "teal"),
]
y = 250
for i, (title, sub, out, col) in enumerate(steps):
    b.append(box(100, y, 420, 82, col, title, [sub], tsize=21, ssize=16))
    b.append(box(600, y, 300, 82, "gray", "produces", [out], tsize=17, ssize=15))
    b.append(arrow([(522, y + 41), (598, y + 41)]))
    if i < 3:
        b.append(box(960, y, 260, 82, "amber", "Human gate", ["read before continuing"], tsize=17, ssize=14))
        b.append(arrow([(902, y + 41), (958, y + 41)]))
        b.append(arrow([(310, y + 82), (310, y + 128)]))
    else:
        b.append(box(960, y, 260, 82, "amber", "Chief architect", ["accepts or returns"], tsize=17, ssize=14))
        b.append(arrow([(902, y + 41), (958, y + 41)]))
    y += 128
b.append(arrow([(60, 200), (60, 291), (98, 291)]))
b.append(label(640, 215, "the gap list is the point of pass 2: it says what to go and find out",
               16, "middle", COL["amber"]["title"], True))
svg(1280, 790, "\n".join(b), OUT + "wow_authoring_passes.svg")

# ============================================================ 3. ELICITATION LOOP
b = []
b.append(box(60, 50, 340, 80, "teal", "Network architect", ["southbound chain"], tsize=19))
b.append(box(470, 50, 340, 80, "teal", "Security architect", ["zoning, entitlements"], tsize=19))
b.append(box(880, 50, 340, 80, "teal", "Delivery lead", ["effort, milestones"], tsize=19))
for x in (230, 640, 1050):
    b.append(arrow([(x, 130), (x, 178)]))
b.append(box(60, 180, 1160, 84, "purple", "Framed conversation",
             ["the system asks; it restates the canonical vocabulary; it confirms before recording"], tsize=21))
b.append(arrow([(640, 264), (640, 312)]))
b.append(box(340, 314, 600, 84, "purple", "Typed statements",
             ["subject, predicate, value — with author, confidence and verbatim"], tsize=21))
b.append(arrow([(640, 398), (640, 446)]))
b.append(box(340, 448, 600, 84, "coral", "Checks",
             ["contradiction, principle violation, stale basis — by query, not by judgement"], tsize=21))
b.append(arrow([(480, 532), (480, 580)]))
b.append(arrow([(800, 532), (800, 580)]))
b.append(box(160, 582, 500, 80, "amber", "Conflicts to arbitrate",
             ["surfaced, never resolved alone"], tsize=19))
b.append(box(700, 582, 500, 80, "gray", "Rendered document",
             ["a projection of the current state"], tsize=19))
b.append(plain([(160, 622), (40, 622), (40, 90), (58, 90)]))
b.append(arrow([(50, 90), (58, 90)]))
b.append(label(60, 676, "returned to its author", 15, "start", TXT2))
svg(1280, 710, "\n".join(b), OUT + "wow_elicitation_loop.svg")

# ============================================================ 4. STATE VS REASONING
b = []
b.append(box(60, 50, 1160, 80, "teal", "Experts and chief architect",
             ["external actors: they answer in their own time, sometimes not at all"], tsize=21))
b.append(arrow([(640, 130), (640, 178)], both=True))
b.append(box(340, 180, 600, 80, "amber", "Question channel",
             ["a mailbox, not a function call"], tsize=21))
b.append(arrow([(640, 260), (640, 308)], both=True))
b.append(box(60, 310, 1160, 90, "purple", "Durable process — the only stateful component",
             ["question lifecycle, routing, waiting, resumption, audit trail"], tsize=21))
b.append(arrow([(640, 400), (640, 448)], both=True))
b.append(label(660, 424, "bounded tasks", 16, "start", TXT2))
tasks = ["Gap detection", "Question writing", "Answer interpretation", "Coherence review"]
for i, t in enumerate(tasks):
    b.append(box(60 + i * 296, 450, 272, 80, "coral", t, [], tsize=18))
b.append(label(640, 552, "stateless agent tasks — replaceable, and never authoritative",
               16, "middle", COL["coral"]["title"]))
b.append(arrow([(196, 578), (196, 626)]))
b.append(label(216, 602, "read", 15, "start", TXT2))
b.append(plain([(1200, 400), (1250, 400), (1250, 656), (960, 656)]))
b.append(arrow([(980, 656), (960, 656)]))
b.append(label(1120, 690, "writes, historised", 15, "middle", TXT2))
b.append(box(340, 628, 600, 80, "gray", "Graph and Git",
             ["statements, assets, history"], tsize=21))
svg(1280, 740, "\n".join(b), OUT + "wow_state_vs_reasoning.svg")
print("four figures generated")

# ============================================================ 5. RUNTIME EXCHANGES
b = []
b.append(box(60, 50, 380, 80, "teal", "Expert",
             ["answers in their own words, confirms what is recorded"], tsize=21))
b.append(box(860, 50, 360, 80, "amber", "Chief architect",
             ["arbitrates, accepts, signs"], tsize=21))
b.append(box(60, 190, 1160, 110, "purple", "Elicitation process — durable, stateful",
             ["holds the question lifecycle, the waiting and the audit trail;",
              "orchestrates everything below and decides nothing itself"], tsize=22, ssize=16))
b.append(box(60, 370, 340, 90, "coral", "Model tasks",
             ["crystallise, interpret,", "render — stateless"], tsize=20, ssize=15))
b.append(box(470, 370, 340, 90, "gray", "Knowledge server",
             ["reusable assets over MCP:", "principles, decisions, patterns"], tsize=20, ssize=15))
b.append(box(880, 370, 340, 90, "gray", "Engagement graph",
             ["statements, questions,", "conflicts — this project"], tsize=20, ssize=15))
b.append(box(470, 540, 340, 80, "purple", "Document",
             ["a projection, regenerable"], tsize=20, ssize=15))
b.append(db.arrow([(250, 190), (250, 132)])); b.append(db.num(275, 160, 1))
b.append(db.arrow([(350, 132), (350, 190)])); b.append(db.num(375, 160, 2))
b.append(db.arrow([(1040, 190), (1040, 132)])); b.append(db.num(1015, 160, 3))
b.append(db.arrow([(1120, 132), (1120, 190)])); b.append(db.num(1145, 160, 4))
b.append(db.arrow([(230, 300), (230, 368)], both=True)); b.append(db.num(255, 334, 5))
b.append(db.arrow([(640, 300), (640, 368)], both=True)); b.append(db.num(665, 334, 6))
b.append(db.arrow([(1050, 300), (1050, 368)], both=True)); b.append(db.num(1075, 334, 7))
b.append(db.arrow([(860, 300), (860, 340), (430, 340), (430, 580), (468, 580)]))
b.append(db.num(430, 470, 8))
b.append(db.arrow([(878, 415), (812, 415)], dashed=True)); b.append(db.num(845, 392, 9))
leg = ["the system asks a framed question", "the expert answers, then confirms the extraction",
       "a contradiction is surfaced", "the arbitration and its rationale come back",
       "crystallising, interpreting, rendering", "frames: principles, prior answers, vocabulary",
       "gap detection and coherence checks, by query", "sections rendered from the statements",
       "harvest: what generalises is promoted by pull request"]
for i, t in enumerate(leg):
    cx = 100 + (i // 5) * 620
    cy = 665 + (i % 5) * 32
    b.append(db.num(cx, cy, i + 1))
    b.append(label(cx + 26, cy + 5, t, 15, "start", TXT))
svg(1280, 830, "\n".join(b), OUT + "wow_runtime_exchanges.svg")

# ============================================================ 6. HOW THE BASE GROWS
b = []
F = "DejaVu Sans, sans-serif"


def bar(x, y, w, h, color, opacity=1.0):
    c = COL[color]
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="{c["fill"]}" '
            f'fill-opacity="{opacity}" stroke="{c["stroke"]}" stroke-width="1.2"/>')


cols = [
    ("Engagement 1", "observed", [("written from scratch", 250, "purple"),
                                  ("confirmed from prior", 0, "teal"),
                                  ("diverged — the delta", 0, "coral")],
     ["45 assets created", "3 questionnaires written", "effort model: a guess"]),
    ("Engagement 2", "expected shape", [("written from scratch", 90, "purple"),
                                        ("confirmed from prior", 110, "teal"),
                                        ("diverged — the delta", 50, "coral")],
     ["≈ 10 new assets", "questionnaires reused as is", "effort model: first actuals"]),
    ("Engagement 3", "expected shape", [("written from scratch", 45, "purple"),
                                        ("confirmed from prior", 155, "teal"),
                                        ("diverged — the delta", 50, "coral")],
     ["≈ 5 new assets", "risks argued from evidence", "effort model: a range with history"]),
]
for i, (name, status, parts, gains) in enumerate(cols):
    x = 110 + i * 390
    b.append(label(x + 145, 70, name, 22, "middle", TXT, True))
    b.append(label(x + 145, 96, status, 15, "middle", TXT2))
    y = 130
    for lbl, h, col in parts:
        if h == 0:
            continue
        b.append(bar(x, y, 290, h, col))
        b.append(label(x + 145, y + h / 2 + 5, lbl, 15, "middle", COL[col]["title"]))
        y += h + 6
    b.append(label(x + 145, 420, "what the base gained", 15, "middle", TXT2, True))
    for j, g in enumerate(gains):
        b.append(label(x + 145, 448 + j * 24, g, 15, "middle", TXT))
b.append(plain([(60, 400), (1220, 400)], width=1.2))
b.append(zone(60, 540, 1160, 130, "The two curves that matter", "gray"))
b.append(label(90, 590, "The reusable core grows slowly and deliberately: promotion requires a second occurrence on a", 16, "start", TXT))
b.append(label(90, 616, "different engagement. The evidence grows with every engagement — prior answers, effort actuals,", 16, "start", TXT))
b.append(label(90, 642, "risks that actually materialised. Small core, accumulating evidence. That is the whole bet.", 16, "start", TXT))
svg(1280, 700, "\n".join(b), OUT + "wow_base_growth.svg")
print("six figures generated")

# ============================================================ 7. ELICITATION WAVES
b = []
b.append(box(60, 50, 700, 76, "purple", "Wave 0 — the brief, filled in one sitting",
             ["one architect, no questions: scope, domains, vendors, platforms, constraints"], tsize=20, ssize=15))
b.append(box(60, 156, 700, 76, "teal", "Wave 1 — structural gaps",
             ["what exists and what is in scope · few questions, high blocking impact"], tsize=20, ssize=15))
b.append(box(60, 262, 700, 76, "teal", "Wave 2 — mechanism gaps",
             ["how each thing works · unlocked once wave 1 has created the subjects"], tsize=20, ssize=15))
b.append(box(60, 368, 700, 76, "teal", "Wave 3 — parameter gaps",
             ["values, sizing, thresholds · the long tail, asked only where they matter"], tsize=20, ssize=15))
for y in (126, 232, 338):
    b.append(db.arrow([(410, y), (410, y + 28)]))
b.append(box(820, 156, 400, 288, "amber", "At any time",
             ["confirmation batches", "", "every gap with a prior answer",
              "becomes a confirm-or-diverge item,", "answered in bulk rather than",
              "asked one at a time"], tsize=20, ssize=15))
b.append(db.arrow([(762, 300), (818, 300)], dashed=True))
b.append(zone(60, 480, 1160, 130, "The rule that makes waves work", "gray"))
b.append(label(90, 530, "A gap whose subject does not yet exist is not a question — it is a downstream gap, suppressed until its", 16, "start", TXT))
b.append(label(90, 556, "prerequisite is satisfied. Without this rule a new engagement generates hundreds of questions on day one,", 16, "start", TXT))
b.append(label(90, 582, "nobody answers any of them, and the instrument is discredited before it has been used once.", 16, "start", TXT))
svg(1280, 640, "\n".join(b), OUT + "wow_elicitation_waves.svg")
print("seven figures generated")

# ============================================================ 8. MATURITY BOARD
b = []
LEV = ["L0 named", "L1 framed", "L2 decomposed", "L3 decided", "L4 specified"]
subjects = [
    ("management-cluster", 4, "\u2014", "5.2 · 6.3"),
    ("fallback-plan", 3, "Q-0014 · bob", "8.5 · 10.4"),
    ("observation-plane", 3, "\u2014", "8.1 · 9.1"),
    ("mcx-interworking", 1, "Q-0021 · alice \u26a0 9 d", "4.2 · 4.3"),
    ("break-glass", 2, "Q-0018 · charlie", "6.3"),
    ("sim-lifecycle", 0, "not started", "4.4"),
]
x0, cw, gap = 430, 96, 8
b.append(label(60, 74, "Subject", 16, "start", TXT, True))
for i, l in enumerate(LEV):
    b.append(label(x0 + i * (cw + gap) + cw / 2, 74, l, 14, "middle", TXT2, True))
b.append(label(960, 74, "Blocked by", 16, "start", TXT, True))
b.append(label(1140, 74, "Sections", 16, "start", TXT, True))
b.append(plain([(60, 88), (1240, 88)], width=1.2))
y = 104
for name, lvl, blocked, secs in subjects:
    b.append(label(60, y + 26, name, 16, "start", TXT))
    for i in range(5):
        col = "teal" if i < lvl else ("amber" if i == lvl else "gray")
        op = 1.0 if i <= lvl else 0.25
        c = COL[col]
        b.append(f'<rect x="{x0 + i * (cw + gap)}" y="{y + 8}" width="{cw}" height="36" rx="5" '
                 f'fill="{c["fill"]}" fill-opacity="{op}" stroke="{c["stroke"]}" '
                 f'stroke-width="1.2" stroke-opacity="{op}"/>')
        if i == lvl:
            b.append(label(x0 + i * (cw + gap) + cw / 2, y + 31, "now", 13, "middle", c["title"], True))
    warn = "\u26a0" in blocked
    b.append(label(960, y + 26, blocked, 14, "start",
                   COL["coral"]["title"] if warn else TXT2, warn))
    b.append(label(1140, y + 26, secs, 14, "start", TXT2))
    y += 52
b.append(plain([(60, y + 4), (1240, y + 4)], width=1.2))
b.append(zone(60, y + 24, 1180, 128, "How to read this board", "gray"))
b.append(label(90, y + 74, "Filled cells are levels reached; the amber cell is where the subject stands now. A section renders as final only when", 15, "start", TXT))
b.append(label(90, y + 98, "its subjects are decided or beyond; below that it renders as provisional. The column that matters in a weekly review is", 15, "start", TXT))
b.append(label(90, y + 122, "not the levels but 'blocked by': a subject stalled at the same level for days, and the name of whoever owes an answer.", 15, "start", TXT))
svg(1280, y + 190, "\n".join(b), OUT + "wow_maturity_board.svg")
print("eight figures generated")

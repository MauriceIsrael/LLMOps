# Changelog

What changed in each delivery of this repository. Newest first.

Convention: a delivery is one handover of the packaged repository. Entries state
what was **added**, **changed**, **superseded** or **removed**, and — where it
matters — *why*, because a changelog that only lists files is a directory
listing with dates.

---

## Delivery 17 — 2026-07-27

**Added**
- `templates/Architecture-as-a-living-asset-base-v2.docx` — version 2 of the
  synthesis note, 15 pages, 6 figures. Three sections are new and carry thinking
  the first version did not have:
  - **§4 Where the questions come from** — the blueprint asks, the knowledge base
    informs, the engagement answers. Gaps are the distance between a section's
    requirement and the engagement's state; the base never creates a question.
  - **§9 Derived, not asserted** — the same mistake made three times in different
    disguises, and the test that separates a knowledge system from a fixture:
    change the input and see whether the output changes.
  - **§10 Integrity** — circular evidence, and the third defence after confidence
    and provenance: two sources corroborate only if neither derives from the other.
  - **§11 Measuring the thing itself** — the recovery benchmark as the first
    quality metric here that is not a matter of opinion.
  - **§15 Where this leads** — what is actually being built, and the honest
    question about whether an organisation wants that much visibility into its
    own reasoning.
- Two working principles added: *derived, not asserted* and *independence before
  corroboration*.

---

## Delivery 16 — 2026-07-27

**Added**
- `tools/elicitation/SPEC-DOCUMENT-INGESTION.md` — feeding a finished document
  back into the pipeline. Three modes selected from a provenance block: derived
  (refused, with a drift report instead), foreign (contribution path), and seed
  (a recovery benchmark measuring the crystallisation pipeline against the
  document the base was originally written from).

**Required change elsewhere**
- The assembler must add a provenance block to every document it produces,
  naming the blueprint, the engagement, the base commit and the statements the
  text was rendered from. Without it, a returning document is indistinguishable
  from foreign material.

**Why** — ingesting a document generated from the base creates circular evidence:
the base ends up appearing to hold two independent sources for one claim. The
natural implementation produces exactly that and nothing would notice.

---

## Delivery 15 — 2026-07-27

**Changed**
- `blueprints/BLU-hla-mcx.yaml` → version 2. Rebuilt against the bid template
  supplied for reference. The previous version reused the template's numbering
  while assigning different subjects to fourteen identifiers — it looked like the
  template and said something else. Titles are now taken verbatim from the
  document, all 44 subsections are present, and the five subsections this
  engagement adds carry `added_by_engagement: true`.
- Five sections are marked `instructed: false` (device fleet, location services,
  radio access, hardware footprint, device ecosystem): they belong to other
  programmes, appear in coverage so the deliverable is complete, and generate no
  question.

**Why** — checked rather than assumed. The divergence was found by comparing the
blueprint to the source document, not by reading it again.

---

## Delivery 14 — 2026-07-27

**Added**
- `blueprints/BLU-hla-mcx.yaml` — the real blueprint, derived from the bid
  template and from the architecture designed for the same system. 49 sections,
  13 root subjects, 10 subjects expected to be discovered by decomposition,
  every `unlocks` target resolving, every section stating what it must answer and
  who it routes to.

**Changed**
- `tools/elicitation/SPEC-PLANNING-AND-DEMO.md` — binding creates the subjects
  listed under `roots` only. A section may require a subject that does not exist
  yet; the requirement holds until a decomposition creates it, which is how the
  dependency between sections becomes visible rather than assumed.

**Why** — the acceptance suite ran on an invented fixture. The fixture stays,
reduced and labelled as such, but the deliverable now has a real structure that
`test_18` validates.

---

## Delivery 13 — 2026-07-27

**Changed**
- `tools/elicitation/test_scenario_nordwave_mcx_v2.py` — section identifiers no
  longer appear in assertions. They are declared once, in the fixture blueprint,
  under semantic keys; assertions look a gap up by what it means through the new
  `gap_for(subject=..., level=...)` helper. The fixture is now labelled as
  reduced rather than passing for the real deliverable.
- `tools/elicitation/FIXES-SCAN.md` — the prohibition on hardcoded names is
  extended to tests, with the distinction that makes it actionable: **subjects
  are vocabulary and may be named; sections are pagination and must not be.**

**Added**
- `test_18_the_real_blueprint_loads_and_validates` — checks the real blueprint
  separately, so that the suite can run on a small fixture without letting the
  actual deliverable's structure drift unnoticed.

**Why** — the suite forbade hardcoded identifiers in `scan.py` and then used
twenty-two of them itself.

---

## Delivery 12 — 2026-07-27

**Added**
- `CHANGELOG.md` — this file, so that each handover states its delta rather than
  leaving it to be reconstructed.
- `tools/elicitation/test_scenario_nordwave_mcx_v2.py` — acceptance suite v2:
  18 tests in six phases, 68 assertions. Covers what v1 could not: blueprint
  binding and subject provenance, gaps proven to be computed rather than
  enumerated, count reconciliation, scan idempotency, per-role capping, the
  level contract on question specificity, the subject trajectory, demotion, and
  the external contribution with its two confirmations.

**Notes**
- v1 of the suite is kept, not deleted: it is the version that produced the first
  real run, and its report is the evidence that three hard properties worked.

---

## Delivery 11 — 2026-07-27

**Added**
- `tools/elicitation/FIXES-SCAN.md` — defect report and fix specification for
  `scan.py`. Ten defects; the first four mean gap detection currently replays a
  hardcoded catalogue rather than computing anything.

**Why it matters** — the observation that only three questions ever came out, and
always the same three, traced to a name-based exemption in the level gate and to
a 35-entry list of every question the system could ever ask.

---

## Delivery 10 — 2026-07-27

**Added**
- `tools/elicitation/SPEC-PLANNING-AND-DEMO.md` — the instruction plan command,
  breadth and depth dispatch strategies, per-role capping, the separation of the
  three planes (blueprint, knowledge, engagement) with provenance markers, and
  card-based file exchange for demonstrations.
- `tools/elicitation/SPEC-REFINEMENT-AND-CONTRIBUTIONS.md` — question templates
  with a `forbids` clause per level, the subject trajectory, demotion, and the
  unsolicited contribution path with triage and two distinct confirmations.

**Changed**
- The blueprint becomes a structured artefact rather than a Markdown asset,
  because it is what generates gaps and therefore needs a schema.

**Superseded**
- The global wave model, which imposed one cadence on a whole engagement, is
  replaced by per-subject maturity. Subjects do not ripen at the same rate.

---

## Delivery 9 — 2026-07-26

**Added**
- `templates/Executive-summary-living-architecture-base.docx` — two pages for
  decision-makers: the problem in business terms, what exists, when it pays, and
  the decision being asked for.

**Changed**
- `templates/Architecture-as-a-living-asset-base.docx` — added the declared
  versus detected conflict distinction, refreshed the state of play, and added a
  section on how we test our own claims, including the episode where writing a
  fabricated scenario exposed a real defect in the specification.

---

## Delivery 8 — 2026-07-26

**Added**
- `tools/elicitation/test_scenario_nordwave_mcx.py` — acceptance suite v1, nine
  tests, one per act, producing the progression report from the graph rather
  than from prose.

**Changed**
- `SPEC.md` gains section 11.1: a conflict carries `origin: declared | detected`.
  A contest is a declaration; `check_node` is the detection. Testing the first
  proves nothing about the second, and only the second is hard.

---

## Delivery 7 — 2026-07-26

**Added**
- `tools/elicitation/SCENARIO-MCX.md` — the Nordwave reference scenario, written
  as a narrative before anything ran.

**Changed**
- The same file, in the same delivery, was reclassified: a banner marks it as
  fabricated rather than a transcript, its front matter carries
  `confidence: assumed`, and a section records where the real run was expected to
  diverge — written before the run so it could not be adjusted afterwards.

**Why it matters** — writing the narrative exposed a defect no reading of the
specification had: the contradiction rule, as written, would not have detected
the cross-predicate conflict the story turns on.

---

## Delivery 6 — 2026-07-26

**Changed**
- The synthesis note was restructured around the final design. The orchestrated
  pipeline and the global wave model were reduced to a paragraph each — the path
  travelled stays visible, but the document leads with where it landed.

**Added**
- Local multi-role mode documented: `--as <person>` resolves author and role from
  the roster, so the three-architect scenario runs on one machine with no
  accounts. It must exercise the same code path as a real contribution.

---

## Delivery 5 — 2026-07-26

**Added**
- `tools/elicitation/SPEC-MAILBOX.md` — four card renderers, the command
  protocol, the GitHub Issues adapter and the file adapter, with idempotency
  markers so a card is upserted rather than duplicated.
- `tools/elicitation/WORKED-EXAMPLE-HLA.md` — the full thread from question to
  rendered HLA section, entirely from a browser.

**Changed**
- `tools/authoring/config.example.yaml` — the service endpoint moved out of
  version control into an environment variable. It had been committed, which
  would have been a leak had the repository ever been made public.

---

## Delivery 4 — 2026-07-25

**Added**
- `tools/elicitation/SPEC.md` — the gap-driven elicitation prototype
  specification: domain model, determinism boundary, three flows, and the
  acceptance test that resumes an interrupted conversation from another process.
- `mcp/SERVER-FIXES.md` — five defects observed on the knowledge server through
  its own tools, with reproduction steps and acceptance criteria.

**Changed**
- `tools/authoring/kb_adapter.py` — an adapter isolating what a given server does
  not provide, so those differences do not leak into the orchestrator. The same
  reasoning as principle P-006, applied to our own tooling.

---

## Delivery 3 — 2026-07-25

**Added**
- `tools/authoring/` — the three-pass orchestrator (check, plan, draft,
  assemble), the MCP client, the prompts, and the assembly pipeline to Word.
- `projects/_template/brief.yaml` — the engagement brief: the facts the base
  cannot know. The input people skip, and the one that decides whether a document
  is specific or generic.
- `AUTHORING.md` — where the human decides, and what each pass is for.

---

## Delivery 2 — 2026-07-25

**Added**
- `GETTING-STARTED.md` — publishing to a remote, branch protection before
  inviting anyone, and the everyday contribution loop.

---

## Delivery 1 — 2026-07-25

**Added**
- The knowledge base itself: 15 principles with their verification clauses,
  13 decisions including a superseded pair kept deliberately, 7 patterns each
  with a "when not to use this" section, 3 vendor questionnaires, an effort model
  with variance drivers, a risk register, view generators, and the specification
  of the read-only knowledge server.
- `CONTRIBUTING.md` and `GOVERNANCE.md` — what goes where and when, the promotion
  rule, the harvest, and the confidence decay enforced by validation.

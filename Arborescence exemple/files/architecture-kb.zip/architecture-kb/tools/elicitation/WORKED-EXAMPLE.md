# Worked example — three architects, one contested decision

This is the reference scenario. It is written to show the **artefacts**, not the
commands: what the system asks, what it proposes to record, what a conflict
looks like, and what arbitration changes in the document. The commands are
incidental — the same sequence through a web interface or a chat channel would
produce exactly these artefacts.

---

## 1. The system scans and finds what is missing

```bash
elicit scan --engagement demo-2026
```

```
Scanning demo-2026 against 5 configured sections…

  G1  empty_section          section 5.2 has no statement about `management-cluster`
  G2  unanswered_blocking    COR-05 unanswered, blocks 8.4 and 10.4
  G3  principle_unaddressed  P-009 constrains 6.3, no statement is based on it

3 gaps, 2 crystallised into questions (cap: 8, sorted by blocked sections).
Q-0001 → role:cloud-architect      blocks 5.2, 6.3
Q-0002 → role:network-architect    blocks 8.4, 10.4
```

The gap list is the first thing worth reading. It is the system saying what the
engagement does not yet know, before anyone writes a paragraph around it.

## 2. What the expert actually receives

```bash
elicit questions --role cloud-architect
```

```
┌─ Q-0001 ────────────────────────────────────── blocks 5.2, 6.3 ─┐
│                                                                  │
│  Which storage backs the management cluster, and is it distinct  │
│  from the storage of the workload clusters?                      │
│                                                                  │
│  Why this matters                                                │
│    P-009 requires an independent failure domain. Without a       │
│    distinct backing store, section 6.3 cannot claim that the     │
│    recovery chain survives an incident on the workloads it       │
│    recovers.                                                     │
│                                                                  │
│  Please use these terms                                          │
│    management-cluster · workload-cluster · failure-domain        │
│                                                                  │
│  Expected                                                        │
│    a storage technology, plus whether it is shared or dedicated  │
│                                                                  │
│  Previously answered elsewhere                                   │
│    mcx-core-2026 → "dedicated array, not shared with workloads"  │
│    confidence: designed                                          │
│    ↳ confirm this, or tell us how it differs here                │
│                                                                  │
│  Constrained by  P-009, ADR-0007                                 │
└──────────────────────────────────────────────────────────────────┘
```

Three things are doing the work here. The question is answerable in one
sentence. The vocabulary is served, so the answer attaches to the right subject
instead of inventing a synonym. And the prior answer is offered as a default, so
the expert confirms or diverges rather than composing from nothing — the
divergence *is* the contribution.

## 3. Alice answers, and sees what will be recorded

```bash
elicit answer Q-0001 --author alice --role cloud-architect \
  --text "We recommend a tier-1 dual-controller NVMe SAN, dedicated to the management cluster."
```

```
Proposed statements — nothing is recorded until you confirm.

  S-0007  management-cluster · has_property · "tier-1 dual-controller NVMe SAN"
          confidence: designed          based on: P-009, ADR-0007
  S-0008  management-cluster · has_property · "storage dedicated, not shared with workload-cluster"
          confidence: designed          based on: P-009

  Your words, kept as recorded:
    "We recommend a tier-1 dual-controller NVMe SAN, dedicated to the
     management cluster."

  [a]ccept   [e]dit   [r]eject
```

This screen is the whole governance model in one place. The extraction is a
proposal; Alice commits it. Her own words are preserved beside the structured
form, so she can later say "that is not what I meant" and prove it.

```bash
elicit confirm Q-0001 --accept
```

```
2 statements recorded. Checks on the new statements only:
  contradiction   none
  stale basis     none
  principle       P-009 now addressed in 6.3  ✓
```

## 4. Bob disagrees, and nothing is overwritten

Bob is not answering Q-0001 — he is contesting an existing statement about a
subject he owns. The system routes his contribution to the same subject.

```bash
elicit contest S-0007 --author bob --role storage-expert \
  --text "Storage should be an all-flash Ceph HCI cluster, converged with the workloads."
```

```
Proposed statement:
  S-0009  management-cluster · has_property · "all-flash Ceph HCI, converged"
          confidence: designed

Recorded. Checks:
  ⚠ CONTRADICTION  C-0001

┌─ C-0001 ─────────────────────────────────────────────────────────┐
│  subject   management-cluster                                     │
│  predicate has_property                                           │
│                                                                   │
│  S-0007  "tier-1 dual-controller NVMe SAN"                        │
│          alice · cloud-architect · designed · 2026-07-26          │
│          based on P-009, ADR-0007                                 │
│                                                                   │
│  S-0009  "all-flash Ceph HCI, converged"                          │
│          bob · storage-expert · designed · 2026-07-26             │
│                                                                   │
│  ⚠ S-0009 also engages P-009: convergence with the workload       │
│    clusters weakens the independent failure domain. Advisory —    │
│    for the arbitrator, not a verdict.                             │
│                                                                   │
│  Both statements remain ACTIVE. Routed to: chief-architect,       │
│  alice, bob.                                                      │
└───────────────────────────────────────────────────────────────────┘
```

Neither statement is withdrawn, neither is silently overwritten, and the system
does not choose. It has surfaced a real architectural disagreement between two
competent people and put it in front of the person whose job that is.

## 5. The document renders anyway, and says why it is provisional

```bash
elicit assemble --engagement demo-2026
```

```
Rendered 5 sections, 2 419 words.

  status        PROVISIONAL
  reason        1 open conflict (C-0001) affecting sections 5.2, 6.3
  also open     Q-0002 unanswered — blocks 8.4, 10.4

Section 5.2 rendered with both positions stated and marked contested.
projects/demo-2026/document.md
```

Rendering is never blocked. A provisional document that names its own defects is
more useful than no document, and it prevents the conflict from becoming a
reason to bypass the process.

## 6. The chief architect arbitrates, with a reason

```bash
elicit arbitrate C-0001 --keep S-0007 \
  --reason "Failure-domain independence outweighs convergence economics here; P-009 is not negotiable on a mission-critical management plane." \
  --by charlie
```

```
C-0001 arbitrated by charlie.
  S-0007  kept, active
  S-0009  superseded by S-0007, reason recorded, author notified

Bob's statement remains in the history with its rationale. It is a candidate for
promotion as a pattern if convergence proves right on another engagement.
```

```bash
elicit assemble --engagement demo-2026
```

```
  status        COMPLETE for the drafted scope
  remaining     Q-0002 unanswered — sections 8.4 and 10.4 still out of scope

Section 5.2 now states the decision and cites the arbitration rationale.
```

---

## What this scenario is meant to demonstrate

- A gap becomes **one answerable question**, carrying its stakes, its vocabulary
  and what was answered elsewhere.
- Extraction is always **shown before it is recorded**, with the contributor's
  own words preserved.
- A disagreement between experts is **detected mechanically** and **arbitrated
  by a human**, with the losing position kept in the history rather than erased.
- The document is a **projection of the current state**, honest about what is
  contested and what is missing.

If a future interface — web or chat — does not make these four things visible,
it will be a prettier version of a command log rather than a demonstration of
the idea.
